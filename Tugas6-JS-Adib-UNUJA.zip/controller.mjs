import users from "./data.mjs";  

const index = () => {  
    // Tampilkan data menggunakan map()  
    users.map(user => {  
        console.log(`Nama: ${user.nama}, Umur: ${user.umur}, Alamat: ${user.alamat}, Email: ${user.email}`);  
    });  
};  

const store = (user) => {  
    // Tambahkan data  
    users.push(user);  
};  

const destroy = (userName) => {  
    // Hapus data berdasarkan nama  
    const index = users.findIndex(user => user.nama === userName);  
    if (index !== -1) {  
        users.splice(index, 1);  
    }  
};  

export { index, store, destroy }; 