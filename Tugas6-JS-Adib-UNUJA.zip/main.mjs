import { index, store, destroy } from "./controller.mjs";  

const main = () => {  
    // Tambahkan dua data baru  
    store({nama: 'Data 13', umur: 32, alamat: 'Jl. Data 13', email: 'data13@example.com'});  
    store({nama: 'Data 14', umur: 33, alamat: 'Jl. Data 14', email: 'data14@example.com'});  

    // Tampilkan semua data  
    index();  

    // Contoh menghapus data  
    destroy('Data 1');  
    console.log('Setelah penghapusan:');  
    index();  
};  

main();  