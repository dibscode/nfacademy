const users = [  
    { nama: 'Andi Setiawan', umur: 28, alamat: 'Jl. Merpati No. 5, Jakarta', email: 'andi.setiawan@example.com' },  
    { nama: 'Siti Aminah', umur: 25, alamat: 'Jl. Anggrek No. 12, Bandung', email: 'siti.aminah@example.com' },  
    { nama: 'Rudi Hartono', umur: 30, alamat: 'Jl. Kenanga No. 14, Surabaya', email: 'rudi.hartono@example.com' },  
    { nama: 'Dina Sari', umur: 33, alamat: 'Jl. Mawar No. 8, Yogyakarta', email: 'dina.sari@example.com' },  
    { nama: 'Budi Prasetyo', umur: 27, alamat: 'Jl. Lili No. 6, Semarang', email: 'budi.prasetyo@example.com' },  
    { nama: 'Fani Nursyifa', umur: 22, alamat: 'Jl. Dahlia No. 3, Medan', email: 'fani.nursyifa@example.com' },  
    { nama: 'Eko Santoso', umur: 31, alamat: 'Jl. Melati No. 10, Palembang', email: 'eko.santoso@example.com' },  
    { nama: 'Lina Permata', umur: 29, alamat: 'Jl. Cempaka No. 15, Batam', email: 'lina.permata@example.com' },  
    { nama: 'Tono Prabowo', umur: 35, alamat: 'Jl. Flamboyan No. 11, Makassar', email: 'tono.prabowo@example.com' },  
    { nama: 'Rina Ayu', umur: 26, alamat: 'Jl. Floria No. 7, Denpasar', email: 'rina.ayu@example.com' }  
];  

// Tambahkan 2 data lagi  
users.push(  
    { nama: 'Irwan Jaya', umur: 24, alamat: 'Jl. Orchid No. 4, Lombok', email: 'irwan.jaya@example.com' },  
    { nama: 'Jessica Putri', umur: 32, alamat: 'Jl. Jasmine No. 9, Cirebon', email: 'jessica.putri@example.com' }  
);  

export default users;  